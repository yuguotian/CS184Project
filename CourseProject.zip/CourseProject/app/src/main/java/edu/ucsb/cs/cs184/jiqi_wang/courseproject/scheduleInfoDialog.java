package edu.ucsb.cs.cs184.jiqi_wang.courseproject;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

public class scheduleInfoDialog extends DialogFragment {
    private static final String ARG_PARAM1 = "param1";
    //private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private Schdeule_info_class mParam1;
    //private String mParam2;

    public scheduleInfoDialog() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static scheduleInfoDialog newInstance(Schdeule_info_class info) {
        scheduleInfoDialog fragment = new scheduleInfoDialog();
        Bundle args = new Bundle();

        args.putSerializable(ARG_PARAM1, info);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.schedule_info_window, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Schdeule_info_class info = (Schdeule_info_class)getArguments().getSerializable(ARG_PARAM1);
        LinearLayout ll = view.findViewById(R.id.ll);

        int counter = 0;

        for(String key : info.getSchedule_info().keySet()){
            counter++;
            ArrayList<String> information = info.getSchedule_info().get(key);
            final String stop1 = information.get(6);
            final String stop2 = information.get(3);

            if(information.size() > 4){ // transit case
                TextView tv = new TextView(view.getContext());
                tv.setText("Route Option " + counter + " :");
                ll.addView(tv);

                tv = new TextView(view.getContext());
                tv.setText("    Take the line " + information.get(1) + "   at  " + information.get(0));
                ll.addView(tv);

                tv = new TextView(view.getContext());
                tv.setText("    Take off at " + information.get(3) + "  at  " + information.get(2));
                ll.addView(tv);

                tv = new TextView(view.getContext());
                tv.setText("    Then take the " + information.get(5) + "  at stop " + information.get(6) + "\n     which leaves at  " + information.get(4));
                ll.addView(tv);

                tv = new TextView(view.getContext());
                tv.setText("    The bus will arrive at " + information.get(7));
                ll.addView(tv);

                tv = new TextView(view.getContext());
                int duration = InfoWindowDialog.compareTime(information.get(0), information.get(7));
                int waiting = InfoWindowDialog.compareTime(information.get(2), information.get(4));
                tv.setText("    Duration " + duration + " minutes" + "   Transit Waiting time: "+ waiting +  " minutes");
                ll.addView(tv);

                tv = new TextView(view.getContext());
                //blank space
                ll.addView(tv);

                Button b = new Button(view.getContext());
                b.setText("View this route on the map!");
                b.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        getDialog().dismiss();
                        MapsActivity.connectingStops(stop1,stop2);
                    }
                });
                ll.addView(b);
                tv = new TextView(view.getContext());
                //blank space
                ll.addView(tv);


            }
            else{
                TextView tv = new TextView(view.getContext());
                tv.setText("Route Option " + counter + " :");
                ll.addView(tv);

                tv = new TextView(view.getContext());
                tv.setText("    Take the " + information.get(1) + "   at  " + information.get(0));
                ll.addView(tv);

                tv = new TextView(view.getContext());
                tv.setText("    Take off at " + information.get(2) + "\n");
                ll.addView(tv);
            }

        }

    }
}
